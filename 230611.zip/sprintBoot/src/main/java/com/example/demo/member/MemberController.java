package com.example.demo.member;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.question.Question;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping("/member")
public class MemberController {

	private final MemberService memberService;

	// 회원가입 처리 -- 사용자에게 정보 받아 Member Db 에 insert
	@GetMapping("/signup")
	public String singup(MemberForm memberForm) {
		return "signup";
	}

	@PostMapping("/signup")
	public String postSingup(@Valid MemberForm memberForm, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "signup";
		}
		if (!memberForm.getPassword().equals(memberForm.getConfirmPassword())) {
			bindingResult.rejectValue("confirmPassword", "passwordInCorrect", "패스워드가 일치하지 않습니다.");
		}

		Member member = new Member();
		member.setEmail(memberForm.getEmail());
		member.setPassword(memberForm.getPassword());
		member.setUserName(memberForm.getUserName());

		try {
			memberService.create(member);
		} catch (DataIntegrityViolationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			bindingResult.rejectValue("signupFailed", "이미 등록 된 email 입니다");
			return "signup";
		} catch (Exception e) {
			bindingResult.rejectValue("signupFailed", e.getMessage());
			return "signup";
		}

		return "redirect:/";
	}

	// 회원 탈퇴 처리 -- Member Db 에서 delete

	// 로그인 처리 -- 조회하여 아이디 비밀번호 맞으면 성공
	@GetMapping("/signin")
	public String singin() {
		return "signin";
	}

	@PostMapping("/signin")
	public String signinPost(@RequestParam(value = "email") String email,
			@RequestParam(value = "password") String password , HttpServletRequest req) {
		Question question = new Question();
		Member member = memberService.findByEmail(email , password);
		HttpSession session = req.getSession();
		System.out.println(member);
		//로그인 성공
		if(member != null) {
			session.setAttribute("member", member);
			return "redirect:/";
		}else {
			return "signin";
		}
	}
	// 로그아웃 처리
	@GetMapping("/signout")
	public String signout(HttpServletRequest req) {
		HttpSession session = req.getSession();
		session.invalidate();
		return "redirect:/";
	}
	
}
