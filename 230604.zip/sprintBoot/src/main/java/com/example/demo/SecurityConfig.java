package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.frameoptions.XFrameOptionsHeaderWriter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration // 환경 설정 하는 파일
@EnableWebSecurity // url 별 security 처리 할지 말지
public class SecurityConfig {
// CSRF = (Cross Site Request Forgery)
// CSRF 토큰값을 발행 , 실제 페이지에서 발행된 정보 인지 검증하는 기술
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http.authorizeHttpRequests((authorizeHttpRequests) -> {
			try {
				authorizeHttpRequests.requestMatchers("/**").permitAll().and().csrf()
						.ignoringRequestMatchers(new AntPathRequestMatcher("/h2-console/**")).and().headers()
						.addHeaderWriter(
								new XFrameOptionsHeaderWriter(XFrameOptionsHeaderWriter.XFrameOptionsMode.SAMEORIGIN));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		return http.build();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}

// 최신화?
//@Bean
//public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//    http
//        .authorizeRequests()
//            .antMatchers("/h2-console/**").permitAll()
//            .and()
//        .csrf()
//            .ignoringRequestMatchers(new AntPathRequestMatcher("/h2-console/**"))
//            .and()
//        .headers()
//            .addHeaderWriter(new XFrameOptionsHeaderWriter(XFrameOptionsHeaderWriter.XFrameOptionsMode.SAMEORIGIN));
//
//    return http.build();
//}

// ------------------- authorizeHttpRequests 문서--------------------------------
//@Configuration
//@EnableWebSecurity
//public class AuthorizeUrlsSecurityConfig {
//
//	@Bean
//	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		http
//			.authorizeHttpRequests((authorizeHttpRequests) ->
//				authorizeHttpRequests
//					.requestMatchers("/**").hasRole("USER")
//			)
//			.formLogin(withDefaults());
//		return http.build();
//	}
//
//	@Bean
//	public UserDetailsService userDetailsService() {
//		UserDetails user = User.withDefaultPasswordEncoder()
//			.username("user")
//			.password("password")
//			.roles("USER")
//			.build();
//		UserDetails admin = User.withDefaultPasswordEncoder()
//			.username("admin")
//			.password("password")
//			.roles("ADMIN", "USER")
//			.build();
//		return new InMemoryUserDetailsManager(user, admin);
//	}
//}
//
//We can also configure multiple URLs. The configuration below requiresauthentication to every URL and will grant access to URLs starting with /admin/ toonly the "admin" user. All other URLs either user can access.  @Configuration
//@EnableWebSecurity
//public class AuthorizeUrlsSecurityConfig {
//
//	@Bean
//	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		http
//			.authorizeHttpRequests((authorizeHttpRequests) ->
//				authorizeHttpRequests
//					.requestMatchers("/admin/**").hasRole("ADMIN")
//					.requestMatchers("/**").hasRole("USER")
//			)
//			.formLogin(withDefaults());
//		return http.build();
//	}
//
//	@Bean
//	public UserDetailsService userDetailsService() {
//		UserDetails user = User.withDefaultPasswordEncoder()
//			.username("user")
//			.password("password")
//			.roles("USER")
//			.build();
//		UserDetails admin = User.withDefaultPasswordEncoder()
//			.username("admin")
//			.password("password")
//			.roles("ADMIN", "USER")
//			.build();
//		return new InMemoryUserDetailsManager(user, admin);
//	}
//}
//
//Note that the matchers are considered in order. Therefore, the following is invalidbecause the first matcher matches every request and will never get to the secondmapping:  @Configuration
//@EnableWebSecurity
//public class AuthorizeUrlsSecurityConfig {
//
//	@Bean
//	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		http
//		 	.authorizeHttpRequests((authorizeHttpRequests) ->
//		 		authorizeHttpRequests
//			 		.requestMatchers("/**").hasRole("USER")
//			 		.requestMatchers("/admin/**").hasRole("ADMIN")
//		 	);
//		return http.build();
//	}
//}
