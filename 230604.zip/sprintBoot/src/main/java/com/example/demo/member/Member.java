package com.example.demo.member;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Member {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)  // 자동 증가속성
	private Integer id;
	
	@NotEmpty(message = "이름을 필수 입니다.")
	private String userName;
	@NotEmpty(message = "비밀번호는 필수 입니다.")
	private String password;
	
	@Column(unique = true)
	@NotEmpty(message = "이메일은 필수 입니다.")
	private String email;
	
}
