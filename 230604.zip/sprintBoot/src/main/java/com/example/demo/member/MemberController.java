package com.example.demo.member;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping("/member")
public class MemberController {

	private final MemberService memberService;
	private final MemberRepository memberRepository; 
	
	//회원가입 처리 -- 사용자에게 정보 받아 Member Db 에  insert
	@GetMapping("/signup")
	public String singup(MemberForm memberForm) {
		return "signup";
	}
	
	@PostMapping("/signup")
	public String postSingup(@Valid MemberForm mf , BindingResult bindingResult) {
		
		if(bindingResult.hasErrors()) {
			return "signup";
		}
		if(!mf.getPassword().equals(mf.getConfirmPassword())){
			bindingResult.rejectValue("confirmPassword", "passwordIncorrect","패스워드가 일치하지 않습니다.");
		}
		
		Member member = new Member();
		member.setEmail(mf.getEmail());
		member.setPassword(mf.getPassword());
		member.setUserName(mf.getUserName());
		memberService.create(member);
		return "redirect:/";
	}
	
	//회원 탈퇴 처리 -- Member Db 에서 delete
	//로그인 처리 -- 조회하여 아이디 비밀번호 맞으면 성공
	//로그아웃 처리
	
	
	
	
	
	
}
