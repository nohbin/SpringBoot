package com.example.demo.question;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import lombok.RequiredArgsConstructor;

//의존관계(Dependency Injection) 주입을 위해 생성자 방식
@RequiredArgsConstructor
// List 를 조회?
@Validated
@Service
public class QuestionService {

	private final QuestionRepository questionRepository;
	
	
	public List<Question> getList(){
		return questionRepository.findAll();
	}


	public Question getDetail(Integer id) {
		Optional<Question> q =  questionRepository.findById(id);
		if(q.isPresent())
			return q.get();
		else 
			throw new DataFoundNotException("Quesion is not found");
		
	}


	public void create(Question question) {
		// TODO Auto-generated method stub
		question.setCreateDate(LocalDateTime.now());
		questionRepository.save(question);
		
	}


	
	
	
	
}
