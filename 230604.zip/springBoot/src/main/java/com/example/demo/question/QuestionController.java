package com.example.demo.question;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

/**
 * html 형식의 코드를 템플릿으로 해서 view 로 사용하는데
 * 이때 사용되는 엔진중에 타임리프(Thymeleaf)(Spring boot) 에서 많이 쓰임) 
 * VeloCity(이전) 와 같은 다른엔진도 사용 됨 - Spring legacy - JSP
 * 
 * 					model
 * Controller - (service - DTO - DB)
 * 
 * @author C-01
 *
 */
@RequestMapping("/question")
@RequiredArgsConstructor
@Controller
public class QuestionController {

//	@Autowired
//	QuestionRepository question;
	private final QuestionService questionService;
	// 템플릿을 사용하여 출력한다.
	// html 을 사용 하는데 동적으로 사용하는것이 아니게 함. Thymeleaf
	@GetMapping("/list")
	public String list(Model model) {
		List<Question> questionLists = questionService.getList();
		model.addAttribute("qlist",questionLists);
		return "question_list"; // 확장자를 제외한 파일명 , 경로는 상관 없음
	}
	
	@GetMapping("/detail/{id}")
	public String detail(Model model , @PathVariable("id") Integer id) {
		Question question = questionService.getDetail(id);
		model.addAttribute("question", question);
		return "question_detail";
	}
	
	@PostMapping("/create")
	public String create(@Valid Question question , BindingResult bindingResult) {
		if(!bindingResult.hasErrors()) {
			question.setSubject(question.getSubject());
			question.setContent(question.getContent());
			questionService.create(question);
		}
			return "redirect:/question/list";
	}
	
}
