package com.example.demo.question;

import java.time.LocalDateTime;
import java.util.List;

import com.example.demo.answer.Answer;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity // Db와 같이 붙어서 작업을 함
@ToString

public class Question {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // 자동 증가 속성 시퀀셜 독립적으로 보유번호 가진 Primary key
	private Integer id;
	
	@Column(length = 200) // DB용도
	@Size(max = 100)
	@NotEmpty(message = "제목은 필수 입니다.")
	private String subject;
	
	@Column(columnDefinition = "TEXT") // 길이 제한 없는 것?
	@NotEmpty(message = "내용은 필수 입니다.")
	private String content;
	
	
	private LocalDateTime createDate;
	
	@OneToMany(mappedBy = "question",cascade = CascadeType.REMOVE) // FK 로 연결 된 db 를 삭제 시 연결된 db 전부 삭제
	private List<Answer> answerList;
}
