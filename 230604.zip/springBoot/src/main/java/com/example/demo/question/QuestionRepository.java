package com.example.demo.question;

import java.util.List;

/**
 * 		AND					: 그리고
 * 		OR					:또는
 * 		BWTWEEN				:~ 사이에 / 주로 기간
 * 		LESSTHAN			: ~ 보다 작다
 * 		GREATERTHANEQUAL	: ~보다 크거나 같다
 * 		LIKE				:문자열 검색
 * 		IN					:여러개 중 하나 일시
 * 		ORDERBY				: 순서 정렬
 */

import org.springframework.data.jpa.repository.JpaRepository;

public interface QuestionRepository extends JpaRepository<Question, Integer> {
	
	List <Question> findBySubject(String str); // subject 의 대소문자를 구별하지 않는다.
	
	List <Question> findBySubjectAndContent(String subject , String content); // AND
	List <Question> findBySubjectLike(String str); // LIKE 
	
	
}
