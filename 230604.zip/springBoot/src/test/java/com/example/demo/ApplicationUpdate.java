package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.question.Question;
import com.example.demo.question.QuestionRepository;

@SpringBootTest
public class ApplicationUpdate {

	@Autowired
	private QuestionRepository qr;
	
	@Test
	public void updateTest1() {
		Optional<Question> oq = qr.findById(1);
		assertFalse(oq.isEmpty());
		Question q= oq.get();
		q.setSubject("반갑습니다");
		qr.save(q);
	}
	
//	@Test
	public void updateTest2() {
		Optional<Question> oq = qr.findById(1);
		Question q= oq.get();
		assertEquals("반갑습니다", q.getSubject());
		
	}

	
}
