package com.example.demo;

import static org.assertj.core.api.Assertions.assertThatList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.question.Question;
import com.example.demo.question.QuestionRepository;

@SpringBootTest
public class ApplicationTest2 {
	
	// Dependency Injection ? ? DI 
	@Autowired
	QuestionRepository qr;
	
	@Test
	public void testSelectAllData(){
		List<Question> allQ = qr.findAll();
		assertEquals(2, allQ.size());
		
		Question q= allQ.get(0);
		assertEquals("안녕하세요 제목1", q.getSubject());
	}
	
	@Test
	public void testSelectByData(){
		Optional<Question> oq = qr.findById(1);
		assertNotNull(oq);
	}
	
	@Test
	public void testSelectBySubject() {
		List <Question> q= qr.findBySubject("안녕하세요 제목1");
		assertThatList(q);
	}
	
	
	
}
