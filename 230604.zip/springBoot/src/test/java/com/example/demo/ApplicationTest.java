package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.answer.Answer;
import com.example.demo.answer.AnswerRepository;
import com.example.demo.question.Question;
import com.example.demo.question.QuestionRepository;

@SpringBootTest
public class ApplicationTest {
	@Autowired
	private QuestionRepository qr; 
	
	@Autowired
	private AnswerRepository ar;
	
//	@Test
//	@Order(1)
	public void testjpa() {
//		qr.deleteAll();
		
		Question q = new Question();
//		q.setSubject("안녕하세요 제목1");
//		q.setContent("반갑습니다 게시글1");
//		q.setCreateDate(LocalDateTime.now());
//		qr.save(q);
//		
//		Question q2 = new Question();
//		q2.setSubject("안녕하세요 제목2");
//		q2.setContent("반갑습니다 게시글2");
//		q2.setCreateDate(LocalDateTime.now());
//		qr.save(q2);
		
		// 댓글 달기
		List<Question> lists = qr.findBySubject("안녕하세요 제목1");
		q = lists.get(0);
		assertNotNull(q); // q가 null 인지 notnull 인지 검사
		Answer a = new Answer();
		a.setContent("스프링부트는 경량 FRAME WORK 입니다 , 최근에 많이 사용합니다."
				+ "/n 또한 자주 사용 하는 설정을 미리 셋팅 할수 있고 그밖에 많은 장점들이 있습니다.");
		a.setCreateDate(LocalDateTime.now());
		a.setQuestion(q);
		ar.save(a);
	}
	
	
	
//		@Test
		public void test3() {
		  Question q = new Question();
		  Optional<Question> list = qr.findById(1);
		  if(list.isPresent()) {
			  q = list.get();
		  }
		  List<Answer> al = ar.findByQuestionId(q.getId());
		  ar.deleteAll(al);
		}
		
		/**
		 * 답변에 연결된 게시글 찾기.
		 */
		@Test
		@Transactional // section 이 끊어지지 않도록 계속 유지하게 만들어주는 FrameWork
		public void test4() {
			// 답변 찾기
			// 전부 찾아 갯수가 1개 이상인지 체크하고 그중에 가장 첫뻔재 답변을 가져온다
			Answer a = new Answer();
			List<Answer> la = ar.findAll();
			assertTrue(la.size()>0);
			
			a = la.get(0);
			Question q = a.getQuestion();
			Optional<Question> oq = qr.findById(q.getId());
			assertTrue(oq.isPresent());
			// 필요한 시점에 시스템을 구동하는걸 lazy Initialization(?) 이라고 한다.
			// 조회를 하고 난 뒤 DB 세션이 끊어진다. 필요한 시점에 데이터를 가져오는 방식을  Lazy 방식이라고 한다
			// Test 할 시에만 발생하는 문제
			
			System.out.println(q.getContent());
			
		}
}

