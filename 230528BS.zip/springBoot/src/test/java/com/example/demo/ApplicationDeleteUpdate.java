package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApplicationDeleteUpdate {

	@Autowired
	private QuestionRepository qr;
	
//	@Test
//	@Order(1) // test 실행 시 Order 순서대로 진행 할수 있게 된다.
	public void updateTest1() {
		Optional<Question> oq = qr.findById(1);
		assertFalse(oq.isEmpty());
		Question q= oq.get();
		q.setSubject("반갑습니다");
		qr.save(q);
	}
	
//	@Test
//	public void delete() {
//		List<Question> q =	qr.deleteById(1);
//		assertNotNull(q);
//	}
	@Test 
	public void delete1() {
		Optional<Question> oq = qr.findById(1);
//		assertTrue(oq.isPresent());
//		qr.delete(oq.get());
		
		oq = qr.findById(1);
		assertTrue(oq.isEmpty());
	}
}
