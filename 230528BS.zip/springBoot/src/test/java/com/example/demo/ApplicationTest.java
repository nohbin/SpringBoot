package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApplicationTest {
	@Autowired
	private QuestionRepository qr; 
	
	@Autowired
	private AnswerRepository ar;
	
	@Test
	public void testjpa() {
//		qr.deleteAll();
		
		Question q = new Question();
//		q.setSubject("안녕하세요 제목1");
//		q.setContent("반갑습니다 게시글1");
//		q.setCreateDate(LocalDateTime.now());
//		qr.save(q);
//		
//		Question q2 = new Question();
//		q2.setSubject("안녕하세요 제목2");
//		q2.setContent("반갑습니다 게시글2");
//		q2.setCreateDate(LocalDateTime.now());
//		qr.save(q2);
		
		// 댓글 달기
		List<Question> lists = qr.findBySubject("안녕하세요 제목1");
		q = lists.get(0);
		assertNotNull(q); // q가 null 인지 notnull 인지 검사
		Answer a = new Answer();
		a.setContent("스프링부트는 경량 FRAME WORK 입니다 , 최근에 많이 사용합니다."
				+ "/n 또한 자주 사용 하는 설정을 미리 셋팅 할수 있고 그밖에 많은 장점들이 있습니다.");
		a.setCreateDate(LocalDateTime.now());
		a.setQuestion(q);
		ar.save(a);
	}
	
	
	/**
	 * 답변에 연결된 게시글 찾기.
	 */
	@Test
	public void testjpa2() {
		

	}

}
