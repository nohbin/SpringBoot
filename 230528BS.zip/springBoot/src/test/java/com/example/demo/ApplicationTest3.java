package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApplicationTest3 {
	@Autowired
	private QuestionRepository qr;
	
//	@Test
	public void test1() {
		List<Question> lists = qr.findBySubjectAndContent("안녕하세요 제목1", "반갑습니다 게시글1");
		assertNotNull(lists);
	}
	
	@Test
	public void test2() {
		List<Question> lists = qr.findBySubjectLike("s");
		assertNotNull(lists);
	}
}
