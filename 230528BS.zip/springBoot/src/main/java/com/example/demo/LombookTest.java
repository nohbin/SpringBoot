package com.example.demo;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor // 생성자 만들 시 final member 를 사용해야 한다.
public class LombookTest {
	private final String name;
	private final int age;
}
