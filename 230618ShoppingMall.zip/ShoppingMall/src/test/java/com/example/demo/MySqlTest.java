package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.demo.constant.ItemSellStatus;
import com.example.demo.entity.Item;
import com.example.demo.repository.ItemRepository;
@SpringBootTest
//@TestPropertySource(locations = "classpath:application.properties")
class MySqlTest {

	@Autowired
	ItemRepository itemRepository;
	
//	@Test
//	@Order(1)
	@DisplayName("상품저장테스트")
	void createItemTest() {
		
		for (int i = 0; i < 10; i++) {
			Item item = new Item();
			item.setItemNm("테스트상품 " + i);
			item.setPrice(10000 + Integer.valueOf(i));
			item.setItemDetail("테스트상품설명");
			item.setStockNumber(100+ Integer.valueOf(i));
			item.setRegTime(LocalDateTime.now());
			item.setUpdateTime(LocalDateTime.now());
			item.setItemSellStatus(ItemSellStatus.SELL);
			itemRepository.save(item);
			
		}
	}
	
	@Test
	@Order(2)
	@DisplayName("상품명조회 테스트")
	void findByItemNMTest() {
		System.out.println("=====================상품명조회 테스트=============================");
		List<Item> itemList = itemRepository.findByItemNm("테스트상품 0");
		assertNotNull(itemList);
		for (Item item : itemList) {
			System.out.println(item);
		}
		System.out.println("=======================================================");
	}
	
	@Test
	@Order(3)
	@DisplayName("상품명과 OR 상세설명 조회 테스트")
	public void test1() {
		System.out.println("===================상품명과 OR 상세설명 조회 테스트============================");
		List<Item> itemList = itemRepository.findByItemNmOrItemDetail("테스트상품 0", "테스트상품설명");
		assertNotNull(itemList);
		for (Item item : itemList) {
			System.out.println(item);
		}
		System.out.println("=======================================================");
	}
	
	@Test
	@Order(4)
	@DisplayName("가격조회 테스트")
	public void test2() {
		System.out.println("====================가격조회 테스트==============================");
		List<Item> itemList = itemRepository.findByPriceLessThan(10005);
		assertNotNull(itemList);
		for (Item item : itemList) {
			System.out.println(item);
		}
		System.out.println("=======================================================");
	}
	
	@Test
	@Order(5)
	@DisplayName("아이템상세설명으로 조회 어노테이션 사용")
	public void test3() {
		System.out.println("====================아이템상세설명으로 조회==============================");
		List<Item> itemList = itemRepository.findByItemDetail("테스트");
		assertNotNull(itemList);
		for (Item item : itemList) {
			System.out.println(item);
		}
		System.out.println("=======================================================");
		
	}
	
}
