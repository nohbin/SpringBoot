package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Item;
import com.example.demo.repository.ItemRepository;

@SpringBootTest
public class MySqlTest2 {
	@Autowired
	ItemRepository itemRepository;
//	
//	@PersistenceContext
//	EntityManager em;
//	
//	@Test
//	@DisplayName("QueryDSL 조회 테스트1")
//	public void queryDslTest() {
//		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
//	}
	
	@Test
	@DisplayName("아이템상세설명으로 조회 어노테이션 사용")
	public void test3() {
		List<Item> itemList = itemRepository.findByItemDetail("테스트상품설명");
		assertNotNull(itemList);
	}
	
	
}
