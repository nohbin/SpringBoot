package com.example.demo.constant;

public enum ItemSellStatus {
	SELL,SOLD_OUT
}
