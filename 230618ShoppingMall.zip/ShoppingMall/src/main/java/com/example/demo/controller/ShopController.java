package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dto.ItemDto;

@Controller
@RequestMapping(value = "/shop")
public class ShopController {
	@GetMapping("/test")
	public String test1(Model model) {
		model.addAttribute("data","안녕하세요 테스트asdasdasd");
		return "test/test";
	}
	
	//ItemDto 에 담아서 출력
	@GetMapping("/test2")
	public String test2(Model model) {
		List<ItemDto> lists = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			ItemDto itemDto = new ItemDto();
			itemDto.setItemNm("핸드폰" + i);
			itemDto.setItemDetail("좋은핸드폰" + i);
			itemDto.setPrice(100000 + Integer.valueOf(i));
			itemDto.setRegTime(LocalDateTime.now());
			itemDto.setUpdateTime(LocalDateTime.now());
			lists.add(itemDto);
		}
		model.addAttribute("itemDtoList",lists);
		return "test/test2";
	}
	
	@GetMapping("/test3")
	public String test3(Model model , String param2 , String param1) {
		System.out.println(param1);
		System.out.println(param2);
		
		return "test/test2"; 
	}
	
	@GetMapping("/test4")
	public String test4() {
		return"test/test3";
	}
	
}
